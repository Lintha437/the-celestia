// scripts/main.ts
import { system } from "@minecraft/server";

//# sourceMappingURL=../debug/main.js.map
